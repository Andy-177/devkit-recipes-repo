===中文===
先运行init.bat，再运行buildsh，然后再buildsh里运行build.sh
init.bat里如果询问你是否在中国请如实选择
如果无法连接github，使用https://gh-proxy.com/或其他转换工具将仓库链接转成镜像站，然后替换repo.txt的链接
构建产物在build文件夹里，clang和python里面是对应语言的产物
===English===
First, run init.bat, then run buildsh, and finally run build.sh within buildsh
If you are asked in init.bat whether you are in China, please choose truthfully
If you cannot connect to GitHub, use https://gh-proxy.com/ or other conversion tools to convert the repository link into a mirror site, and then replace the link in repo.txt
The build artifacts are located in the build folder, with clang and python producing artifacts for their respective languages