@echo off
set "APP_DIR=%~dp0"
call %APP_DIR%msys64/msys2_shell.cmd -defterm -here -no-start -ucrt64 %*