@echo off
set "APP_DIR=%~dp0"
msys2-base-x86_64-20260927.sfx.exe
choice /c YN /m "你在中国吗(Are you in China?)"
if errorlevel 2 goto end
if errorlevel 1 goto cofigsource
:cofigsource
robocopy "%APP_DIR%source" "%APP_DIR%msys64\etc\pacman.d"
echo 镜像源配置完毕
goto end
:end
echo 你的构建环境已经初始化完毕，使用buildsh进入构建环境
echo Your build environment has been initialized. Use "buildsh" to enter the build environment
pause